/*
 * Allegro DIALOG Editor
 * by Julien Cugniere
 *
 * pluginit.c : Function initializing all the plugins. Put in a separate file
 *              to avoid recompiling the whole dedit.c file each time a
 *              plugin is installed.
 */

#include "dedit.h"

/* Generating plugins.h from the makefile in a platform independent way is
 * troublesome because of the characters '(', ')' and ';' might or might not
 * be interpreted by the shell. These two macros solve the problem.
 */
#define F_DECL (void);
#define F_CALL ();


void init_plugins(void)
{
	#include "plugins.h"
}
