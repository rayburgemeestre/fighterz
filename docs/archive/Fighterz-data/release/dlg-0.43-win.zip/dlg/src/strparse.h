/*
 * Allegro DIALOG Editor
 * by Julien Cugniere
 *
 * strparse.h : String parsing functions
 */

#ifndef STRPARSE_H
#define STRPARSE_H

#define NCHAR 1024 // ugly, eh :)

#ifdef __cplusplus
	extern "C" {
#endif


char *get_copy(char *str);
void str_skip_ws(char **is);
char *littostr(char *buff, char *lit);
char *get_string(char *buff, char *lit);
int get_number(char *s);
int get_flags(char *s);
int get_key(char *str);
char *make_flags(char *buff, int flags);


#ifdef __cplusplus
	}
#endif

#endif /* STRPARSE_H */
