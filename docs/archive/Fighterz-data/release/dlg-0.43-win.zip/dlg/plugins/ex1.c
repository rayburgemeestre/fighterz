/*
 * Simple example plugin changing the font and colors of the edited dialog
 */

#include <allegro.h>

void install_ex1_plugin(void)
{
	DATAFILE *df;

	/* change the font, will only affect the edited dialog */
	df = load_datafile("font.dat");
	if (df)
		font = df[0].dat;

	/* change the colors (you could also load a palette, etc.) */
	gui_fg_color = makecol(255, 255, 0  );
	gui_bg_color = makecol(0,   0,   127);
	gui_mg_color = makecol(127, 127, 63 );
}
